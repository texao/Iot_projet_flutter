import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  //  widget racine de l'application
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(

        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
        useMaterial3: true,
      ),
      home: const QuizzPage()// acceder directement au quizz
    );
  }
}





class Question {
  String questionText;
  bool isCorrect;
  String? imageUrl;  // Image URL si la question a une image


  Question({required this.questionText, required this.isCorrect, this.imageUrl,});
}


class QuizzPage extends StatefulWidget {
  const QuizzPage({Key? key}) : super(key: key);

  @override
  State<QuizzPage> createState() => _QuizzPageState();
}

class _QuizzPageState extends State<QuizzPage> {
  // Liste des questions
  final List<Question> questions = [
    Question(questionText: "Flutter est développé par Google ?", isCorrect: true, imageUrl: 'https://i.ytimg.com/vi/DG-R95e2GsA/maxresdefault.jpg'),
    Question(questionText: "Dart est utilisé pour Flutter ?", isCorrect: true),
    Question(questionText: "Flutter ne supporte pas iOS ?", isCorrect: false),
    Question(questionText: "Flutter utilise un moteur de rendu basé sur le moteur WebView pour afficher les interfaces utilisateur ?", isCorrect: false,
        imageUrl: 'https://www.initiotechmedia.com/wp-content/uploads/2023/04/runapp-730x400.png')
  ];

  int IndexQuestionCourante = 0; // Suivi de la question en cours
  int score = 0; // Score utilisateur

  // Vérification de la réponse
  void checkAnswer(bool userChoice) {
    if (questions[IndexQuestionCourante].isCorrect == userChoice) {
      setState(() {
        score++;
      });
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text('Bonne réponse !'),
        backgroundColor: Colors.green,
      ));
    } else {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text('Mauvaise réponse !'),
        backgroundColor: Colors.red,
      ));
    }
    nextQuestion();
  }

  // Passer à la question suivante
  void nextQuestion() {
    setState(() {
      if (IndexQuestionCourante < questions.length - 1) {
        IndexQuestionCourante++;
      } else {
        showResult();
      }
    });
  }

  // Afficher le résultat final
  void showResult() {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Résultat du Quizz'),
        content: Text('Vous avez obtenu $score/${questions.length} points.'),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              setState(() {
                IndexQuestionCourante = 0;
                score = 0;
              });
            },
            child: const Text('Recommencer'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Quizz Flutter'),
        backgroundColor: Colors.blueAccent,
      ),
      backgroundColor: Colors.blueGrey[50],
      body: Padding(
        padding: const EdgeInsets.all(16.0),

        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [

            // afficher l'images si il y en a
            if(questions[IndexQuestionCourante].imageUrl != null)
              Column(
              children: [
              Image.network(
                questions[IndexQuestionCourante].imageUrl!,
                width: 400,
                height: 300,
                fit: BoxFit.cover,

              ),
                const SizedBox(height: 100),
            ],
              ),


            Text( // afficher la question
              questions[IndexQuestionCourante].questionText,
              style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
              textAlign: TextAlign.center,
            ),

            const SizedBox(height: 100),



            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                ElevatedButton(
                  onPressed: () => checkAnswer(true),
                  child: const Text('Vrai'),
                ),
                ElevatedButton(
                  onPressed: () => checkAnswer(false),
                  child: const Text('Faux'),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}


