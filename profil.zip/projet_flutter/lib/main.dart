import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // widget racine de l'application
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(

        colorScheme: ColorScheme.fromSeed(seedColor: Colors.blue),
        useMaterial3: true,

      ),
      home: const MyHomePage(title: 'Profil page'),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key, required this.title});


  final String title;

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          widget.title,
          style: const TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 25,
            color: Colors.white,
          ),
        ),
          centerTitle: true,
          backgroundColor: Colors.blueAccent,
          elevation: 4,
      ),

      body: Center(
        child: ProfileCard(), // Profile Card widget
      ),

      floatingActionButton: FloatingActionButton(
        child: Icon(Icons.account_circle),
        onPressed: (){
          print("profil utilisateur");
        }),
    );
  }

  }



class ProfileCard extends StatelessWidget {
  const ProfileCard({super.key});


  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 5,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(15),
      ),
      child: Padding(
        padding: const EdgeInsets.all(18.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: <Widget>[
            // Avatar section
            CircleAvatar(
              radius: 120,
              backgroundImage: NetworkImage(
                  'https://attic.sh/u9k96565omiqpu2y2yjsi39ki8iy'),
              // Remplace par une URL d'image valide
              backgroundColor: Colors.transparent,
            ),
            const SizedBox(height: 30), // Espace entre l'avatar et le texte
            // Information section
            Text(
              'SAR Alexandre',
              style: Theme
                  .of(context)
                  .textTheme
                  .headlineMedium,

            ),

            const SizedBox(height: 20),

            // Details Column
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                ProfileDetailRow(  //  email
                  icon: Icons.email,
                  label: "Email",
                  value: "exemple@exemple.com",
                ),
                ProfileDetailRow(  // lien twitter
                  icon: Icons.link,
                  label: "Twitter",
                  value: "twitter@example",
                ),
                ProfileDetailRow(   // adresse
                  icon: Icons.home,
                  label: "Adresse",
                  value: "119 avenue St André de Novigens",
                ),
                ProfileDetailRow(    // ville
                  icon: Icons.location_city,
                  label: "Ville",
                  value: "Montpellier",
                ),
              ],
            ),

            const SizedBox(height: 30),
            // Interactive buttons
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                ElevatedButton.icon(
                  onPressed: () {
                    // Action pour supprimer
                    print("Profil partagé");
                  },
                  icon: const Icon(Icons.share),
                  label: const Text("Partager"),
                ),


                ElevatedButton.icon(
                  onPressed: () {
                    // Action pour modifier
                    print("Profil modifié");
                  },
                  icon: const Icon(Icons.edit),
                  label: const Text("Modifier"),
                ),
              ],
            )


          ],
        ),
      ),
    );
  }
}

class ProfileDetailRow extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;

  const ProfileDetailRow({
    super.key,
    required this.icon,
    required this.label,
    required this.value,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 10.0),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Icon(icon, color: Colors.blue.shade700, size: 30),
          const SizedBox(width: 18),
          Expanded(
            child: Text(
              "$label: $value",
              style: GoogleFonts.poppins(
                textStyle: TextStyle(
                    color: Colors.black87,
                    fontSize: 19,
                    fontWeight: FontWeight.w600, // Semi-gras
                    letterSpacing: 0.5,    // Espacement
                    fontStyle: FontStyle.italic,
                    shadows: [
                      Shadow(
                          offset: Offset(5, 5),
                          blurRadius: 3,
                          color: Colors.grey.withOpacity(0.5)
                      )
                    ]
                ),

              ),
            ),
          ),
        ],
      ),
    );
  }
}